
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Star, MapPin, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-pink-50 text-gray-800">
      <header className="p-6 text-center">
        <h1 className="text-4xl font-bold text-pink-700">NessmaStay</h1>
        <p className="text-lg mt-2">Explore Tunisia safely, affordably, and beautifully.</p>
      </header>

      <section className="p-6 grid md:grid-cols-3 gap-4">
        <Card className="bg-white rounded-2xl shadow-md">
          <CardContent className="p-4">
            <MapPin className="text-pink-600 mb-2" />
            <h2 className="font-semibold text-xl">Discover Tunisia</h2>
            <p className="text-sm mt-2">Travel across all 24 governorates and experience unique stays hosted by local women.</p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-2xl shadow-md">
          <CardContent className="p-4">
            <ShieldCheck className="text-pink-600 mb-2" />
            <h2 className="font-semibold text-xl">Safety First</h2>
            <p className="text-sm mt-2">Feel secure with verified female-only hosts and support around the clock.</p>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-2xl shadow-md">
          <CardContent className="p-4">
            <Star className="text-pink-600 mb-2" />
            <h2 className="font-semibold text-xl">Top Experiences</h2>
            <p className="text-sm mt-2">Enjoy curated stays, local meals, and cultural adventures without the high price tag.</p>
          </CardContent>
        </Card>
      </section>

      <section className="p-6 text-center">
        <Button className="bg-pink-600 hover:bg-pink-700 text-white rounded-2xl px-6 py-2 text-lg">
          Download the App
        </Button>
      </section>

      <footer className="p-6 bg-pink-100 text-center text-sm text-pink-700">
        <p>&copy; 2025 NessmaStay. All rights reserved.</p>
        <div className="mt-4 grid gap-2 md:grid-cols-4 text-xs">
          <a href="#features" className="hover:underline">Features</a>
          <a href="#reviews" className="hover:underline">Reviews</a>
          <a href="#contact" className="hover:underline">Contact</a>
          <a href="#about" className="hover:underline">About the Owner</a>
        </div>
      </footer>
    </div>
  );
}
